THIS FEATURE IS CURRENTLY A WORK IN PROGRESS
<br>
<a class="btn btn-outline-primary" href="./signout.php">Sign out</a>